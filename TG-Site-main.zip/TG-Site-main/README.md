(Fixed the issue with my name not showing up - TP)

(I thought TP was Spence.. I'm dumb LOL - Aimee)

This is the [thicc.games website](https://thicc.games) project.

# DIY Perspective
If you feel like something's not right (e.g. terrible code, think something should be moved up), do it yourself!
It doesn't hurt and any change can be a really positive one.

For example, a lot of the code I did was REALLY unorthodox. It looks TERRIBLE, and it's implemented terribly, but it **works!**
If you feel like I should change said code, then do it yourself! Not in a rude way :) (i really want a better implementation of blogs lol)

## Getting Started

First, run the development server:

```bash
npm run dev
```
## NOTE: yarn & pnpm are **NOT** supported! Please do NOT run either command, otherwise building it will fail. Just use NPM!

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

Make sure to commit ALL your changes (when stable, of course!).

[API routes](https://nextjs.org/docs/api-routes/introduction) can be accessed on [http://localhost:3000/api/](http://localhost:3000/api/). For example, one of the endpoints can be edited in `pages/api/getDriverID.ts`.

The `pages/api` directory is mapped to `/api/*`. Files in this directory are treated as [API routes](https://nextjs.org/docs/api-routes/introduction) instead of React pages.

This project uses [`next/font`](https://nextjs.org/docs/basic-features/font-optimization) to automatically optimize and load Inter, a custom Google Font.

## Deployment

This project currently runs on Heroku, you can view the Heroku directly at [https://thicc-games.herokuapp.com](https://thicc-games.herokuapp.com/).

## Tips

Make sure not to blunder like how I did... make sure to replace 's with `&rsquo;`. Otherwise, Heroku will whine and not build it :(
