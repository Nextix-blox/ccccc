import React from 'react';
import Redirect from '@/functions/redirect';

const MyComponent: React.FC = () => {
	return <Redirect url="https://forms.gle/FDZ6cu4MdkufB2mx9" />;
};

export default MyComponent;