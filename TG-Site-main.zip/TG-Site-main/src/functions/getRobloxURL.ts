export function getRobloxURL(): string {
    return "https://www.roblox.com/games/12218739418/TG-My-Resturant-Beta"
}