export default function ImageSlider2(): JSX.Element {
	return <></>;
}
